# Windows Workstation setup

Include the setups to setup a workstation for the project
and include the install commands

