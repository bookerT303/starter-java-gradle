# Project starter for gradle and java

[Getting started](docs/starting.md)

## Setup
[OSX workstation setup](docs/osx-setup.md)
[Windows workstation setup](docs/windows-setup.md)

## Patterns

1. [Add a REST API](docs/rest-api.md)

